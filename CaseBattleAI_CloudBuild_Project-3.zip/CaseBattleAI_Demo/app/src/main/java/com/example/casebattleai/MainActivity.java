package com.example.casebattleai;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

public class MainActivity extends Activity {
    private final int BG = Color.rgb(4, 10, 25);
    private final int PANEL = Color.rgb(9, 23, 48);
    private final int BLUE = Color.rgb(42, 190, 255);
    private final int TEXT = Color.rgb(235, 244, 255);
    private LinearLayout root, content;
    private EditText balanceInput, chatInput;
    private TextView status;
    private double balance = 500.0;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        showHome();
    }

    private GradientDrawable shape(int color, int stroke) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(28);
        d.setStroke(2, stroke);
        return d;
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value); t.setTextSize(size); t.setTextColor(color);
        t.setGravity(Gravity.CENTER_VERTICAL);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setPadding(8, 6, 8, 6);
        return t;
    }

    private LinearLayout column() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(18, 14, 18, 14);
        return l;
    }

    private void setup(String title) {
        root = column();
        root.setBackgroundColor(BG);
        TextView heading = text("CASEBATTLE AI", 24, BLUE, true);
        heading.setGravity(Gravity.CENTER);
        root.addView(heading);
        TextView sub = text(title, 14, Color.LTGRAY, false);
        sub.setGravity(Gravity.CENTER);
        root.addView(sub);
        ScrollView scroll = new ScrollView(this);
        content = column();
        scroll.addView(content);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);
    }

    private Button button(String label, Runnable action) {
        Button b = new Button(this);
        b.setText(label); b.setTextColor(Color.WHITE);
        b.setBackground(shape(Color.rgb(5, 48, 100), BLUE));
        b.setOnClickListener(v -> action.run());
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.setMargins(0, 8, 0, 8);
        b.setLayoutParams(p);
        return b;
    }

    private void panel(String message) {
        TextView t = text(message, 15, TEXT, false);
        t.setPadding(16, 14, 16, 14);
        t.setBackground(shape(PANEL, Color.rgb(16, 88, 155)));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.setMargins(0, 8, 0, 8);
        content.addView(t, p);
    }

    private void showHome() {
        setup("Демо-анализ · без подключения к сайту");
        panel("Умный помощник для учебных расчётов. Все кейсы и вероятности ниже — вымышленные примеры, не актуальные данные Case Battle.");
        TextView start = text("START", 34, BLUE, true);
        start.setGravity(Gravity.CENTER);
        start.setPadding(10, 34, 10, 34);
        start.setBackground(shape(Color.rgb(4, 25, 65), BLUE));
        content.addView(start, new LinearLayout.LayoutParams(-1, -2));
        content.addView(button("Открыть демо-меню", this::showMenu));
        panel("Баланс для демонстрации: 500 условных единиц");
        panel("Важно: приложение ничего не покупает, не делает ставки и не подключается к аккаунту.");
    }

    private void showMenu() {
        setup("Главное меню");
        content.addView(button("Тест прогноза · вероятности", this::showForecast));
        content.addView(button("Найти лучший кейс · Тактика", this::showTactics));
        content.addView(button("Анализ примеров кейсов", this::showCases));
        content.addView(button("Калькулятор апгрейда", this::showUpgrade));
        content.addView(button("Мини-чат", this::showChat));
        content.addView(button("Изменить демо-баланс", this::showBalance));
        content.addView(button("На главную", this::showHome));
    }

    private void showBalance() {
        setup("Демо-баланс");
        panel("Введите сумму вручную. Она хранится только в текущем запуске приложения.");
        balanceInput = new EditText(this);
        balanceInput.setSingleLine(true);
        balanceInput.setInputType(8194);
        balanceInput.setText(String.valueOf((int)balance));
        balanceInput.setTextColor(TEXT);
        balanceInput.setHintTextColor(Color.GRAY);
        balanceInput.setHint("Сумма");
        content.addView(balanceInput);
        content.addView(button("Сохранить", () -> {
            try {
                double v = Double.parseDouble(balanceInput.getText().toString());
                if (v < 0) throw new NumberFormatException();
                balance = v;
                showMenu();
            } catch (Exception e) { panel("Введите корректное число, например 500."); }
        }));
        content.addView(button("Назад", this::showMenu));
    }



    private void showForecast() {
        setup("Тест прогноза · учебная модель");
        panel("Это не предсказание конкретного выпадения. Приложение может оценить только вероятности, если они известны. Здесь используются вымышленные данные для теста.");
        panel("Тестовый кейс: цена 100 условных единиц.\nВымышленные результаты:\n40 единиц — шанс 70%\n100 единиц — шанс 25%\n300 единиц — шанс 5%");
        double price = 100.0;
        double pLoss = 0.70;
        double pBreakEven = 0.25;
        double pProfit = 0.05;
        double ev = 40*pLoss + 100*pBreakEven + 300*pProfit;
        double pNoProfit = pLoss + pBreakEven;
        panel("Расчёт по заданным шансам:\nВероятность получить меньше цены открытия: " +
            String.format("%.0f", pLoss*100) + "%\nВероятность получить ровно цену: " +
            String.format("%.0f", pBreakEven*100) + "%\nВероятность получить больше цены: " +
            String.format("%.0f", pProfit*100) + "%\nОжидаемая стоимость: " +
            String.format("%.2f", ev) + "\nОжидаемая разница относительно цены: " +
            String.format("%+.2f", ev-price));
        panel("Вывод модели: по этим вымышленным данным ожидаемая стоимость ниже цены. Это не означает, что известно, какой предмет выпадет в следующем открытии. Каждое случайное открытие не раскрывает заранее свой результат.");
        panel("Для анализа реального набора данных нужны опубликованные шансы, полный список предметов, актуальные цены и комиссии. Если чего-то нет, правильный ответ — «недостаточно данных», а не придуманный прогноз.");
        content.addView(button("Назад", this::showMenu));
    }

    private void showTactics() {
        setup("Тактика · сравнение вариантов");
        panel("Демонстрационный подбор по ожидаемой стоимости. Все данные вымышленные; это не прогноз реального сайта и не гарантия окупаемости.");
        final double[][] cases = {
            {100, 0.70, 0.25, 0.05, 40, 100, 300},
            {150, 0.50, 0.35, 0.15, 60, 150, 500},
            {200, 0.80, 0.15, 0.05, 100, 250, 700}
        };
        final String[] names = {"Пример «Синий»", "Пример «Неон»", "Пример «Космос»"};
        double bestScore = -Double.MAX_VALUE;
        int bestIndex = -1;
        double[] evs = new double[cases.length];
        for (int i = 0; i < cases.length; i++) {
            double[] c = cases[i];
            evs[i] = c[1]*c[4] + c[2]*c[5] + c[3]*c[6];
            double net = evs[i] - c[0];
            if (c[0] <= balance && net > bestScore) {
                bestScore = net;
                bestIndex = i;
            }
        }
        panel("Демо-баланс: " + String.format("%.2f", balance) + " условных единиц.");
        for (int i = 0; i < cases.length; i++) {
            double price = cases[i][0];
            double net = evs[i] - price;
            String label = names[i] + "\nЦена: " + price +
                "\nОжидаемая стоимость: " + String.format("%.2f", evs[i]) +
                "\nОжидаемая разница: " + String.format("%+.2f", net) +
                "\nДоля баланса на одно открытие: " + String.format("%.1f", 100*price/balance) + "%";
            if (i == bestIndex) label += "\nЛучший по этому демо-расчёту среди вариантов в пределах баланса.";
            if (net < 0) label += "\nРасчётное ожидание отрицательное.";
            else label += "\nПоложительное ожидание не гарантирует прибыль в отдельном случае.";
            panel(label);
        }
        if (bestIndex < 0) panel("Нет вариантов в пределах указанного демо-баланса.");
        panel("Тактика: не считать один удачный результат закономерностью. При неизвестных шансах, комиссиях или ценах вывод должен быть «недостаточно данных». В этой демо-версии кейсы не открываются и реальные сайты не подключаются.");
        content.addView(button("Назад", this::showMenu));
    }

    private void showCases() {
        setup("Демо-анализ кейсов");
        panel("Данные полностью вымышленные. В приложении нет доступа к Case Battle.");
        addCase("Пример «Синий»", 100, new double[]{0.70,0.25,0.05}, new double[]{40,100,300});
        addCase("Пример «Неон»", 150, new double[]{0.50,0.35,0.15}, new double[]{60,150,500});
        addCase("Пример «Космос»", 200, new double[]{0.80,0.15,0.05}, new double[]{100,250,700});
        content.addView(button("Назад", this::showMenu));
    }

    private void addCase(String name, double price, double[] probs, double[] values) {
        double ev = 0;
        for (int i=0;i<probs.length;i++) ev += probs[i] * values[i];
        String result = ev - price >= 0 ? "В этом учебном примере EV не ниже цены." : "В этом учебном примере EV ниже цены.";
        panel(name + "\nЦена примера: " + price + "\nОжидаемая стоимость: " + String.format("%.2f", ev) +
                "\nРазница EV − цена: " + String.format("%.2f", ev-price) + "\n" + result +
                "\nВероятности условные; не прогноз и не совет потратить деньги.");
    }

    private void showUpgrade() {
        setup("Калькулятор апгрейда");
        panel("Введите исходную стоимость, стоимость цели и подтверждённую вероятность успеха. Пример демонстрационный.");
        EditText cost = field("Стоимость исходного предмета, например 100");
        EditText target = field("Стоимость целевого предмета, например 250");
        EditText chance = field("Вероятность успеха в %, например 40");
        content.addView(cost); content.addView(target); content.addView(chance);
        TextView output = text("", 15, TEXT, false);
        content.addView(output);
        content.addView(button("Рассчитать", () -> {
            try {
                double c = Double.parseDouble(cost.getText().toString());
                double t = Double.parseDouble(target.getText().toString());
                double p = Double.parseDouble(chance.getText().toString()) / 100.0;
                if (c < 0 || t < 0 || p < 0 || p > 1) throw new Exception();
                double ev = p*t;
                output.setText("Шанс успеха: " + String.format("%.1f",p*100) + "%\n" +
                    "Условная ожидаемая стоимость цели с учётом неуспеха: " + String.format("%.2f",ev) +
                    "\nСравнение с исходной стоимостью: " + String.format("%.2f",ev-c) +
                    "\nРезультат зависит от реальных правил и потерь при неуспехе; без них вывод неполный.");
            } catch(Exception e) { output.setText("Проверь числа и введи вероятность от 0 до 100."); }
        }));
        content.addView(button("Назад", this::showMenu));
    }

    private EditText field(String hint) {
        EditText e = new EditText(this);
        e.setHint(hint); e.setTextColor(TEXT); e.setHintTextColor(Color.GRAY);
        e.setInputType(8194);
        return e;
    }

    private void showChat() {
        setup("Мини-чат · офлайн-демо");
        panel("Привет! Я демонстрационный помощник. Я могу объяснить расчёты, но пока не подключён к модели ИИ или сайту.");
        chatInput = new EditText(this);
        chatInput.setHint("Напиши вопрос...");
        chatInput.setTextColor(TEXT); chatInput.setHintTextColor(Color.GRAY);
        content.addView(chatInput);
        status = text("", 15, TEXT, false);
        content.addView(status);
        content.addView(button("Отправить", () -> {
            String q = chatInput.getText().toString().trim().toLowerCase();
            if (q.isEmpty()) { status.setText("Напиши вопрос."); return; }
            String answer;
            if (q.contains("баланс")) answer = "Демо-баланс сейчас: " + balance + " условных единиц. Изменить его можно в меню.";
            else if (q.contains("апгрейд") || q.contains("шанс") || q.contains("процент"))
                answer = "Для расчёта нужны вероятность успеха, стоимость цели и стоимость исходного предмета. Неизвестный шанс нельзя достоверно угадать.";
            else if (q.contains("кейс") || q.contains("окуп"))
                answer = "Сравни ожидаемую стоимость предметов с ценой и учитывай комиссии. Все кейсы в этой сборке вымышленные.";
            else answer = "Это офлайн-демо без ИИ. Попробуй спросить про баланс, кейс, окупаемость или апгрейд.";
            status.setText("Ты: " + chatInput.getText().toString() + "\n\nCaseBattle AI: " + answer);
        }));
        content.addView(button("Назад", this::showMenu));
    }
}
